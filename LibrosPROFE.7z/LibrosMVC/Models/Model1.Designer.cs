﻿// La generación de código predeterminada está deshabilitada para el modelo 'c:\users\-c3\documents\visual studio 2012\Projects\LibrosMVC\LibrosMVC\Models\Model1.edmx'. 
// Para habilitar la generación de código predeterminada, cambie el valor de la propiedad del diseñador 'Estrategia de generación de código'
// por otro valor. Esta propiedad está disponible en la ventana Propiedades cuando se abre
// el modelo en el diseñador.