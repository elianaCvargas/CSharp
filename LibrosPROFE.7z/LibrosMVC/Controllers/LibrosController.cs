﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LibrosMVC.Models;

namespace LibrosMVC.Controllers
{
    public class LibrosController : Controller
    {
        private LibrosEntities db = new LibrosEntities();

        //
        // GET: /Libros/

        public ActionResult Index()
        {
            var libros = db.Libros.Include(l => l.Editorial);
            ViewBag.edi = new SelectList(db.Editorial, "EditorialID", "Nombre");

            return View(libros.ToList());
        }



        public ActionResult QuitarGenero(int id = 0, string id2 = null)
        {
            var libros = db.Libros.Find(id2);
            libros.Genero.Remove(db.Genero.Find(id));
            db.SaveChanges();
            return RedirectToAction("Edit", new {id=libros.ISBN });
  
        }

        [HttpPost]
        public ActionResult Index(FormCollection fm)
        {
            ViewBag.edi = new SelectList(db.Editorial, "EditorialID", "Nombre");
            string post = (fm["edi"]);
            if (post == "")
            {
                return View(db.Libros);
            }
            int id =int.Parse(post);
            
            return View(db.Libros.Where(a => a.EditorialID == id));
        }

        //
        // GET: /Libros/Details/5

        public ActionResult Details(string id = null)
        {
            Libros libros = db.Libros.Find(id);
            if (libros == null)
            {
                return HttpNotFound();
            }
            return View(libros);
        }

        //
        // GET: /Libros/Create

        public ActionResult Create()
        {
            ViewBag.EditorialID = new SelectList(db.Editorial, "EditorialID", "Nombre");
            return View();
        }

        //
        // POST: /Libros/Create

        [HttpPost]
        public ActionResult Create(Libros libros,FormCollection fm)
        {
            if (ModelState.IsValid)
            {
                Autor au = new Autor();
                au.Nombre = Request["Aut"];

                Genero gen = new Genero();
                gen.Nombre = fm["Gen"];

                libros.Autor.Add(au);
                libros.Genero.Add(gen);

                db.Libros.Add(libros);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.EditorialID = new SelectList(db.Editorial, "EditorialID", "Nombre", libros.EditorialID);
            return View(libros);
        }

        //
        // GET: /Libros/Edit/5

        public ActionResult Edit(string id = null)
        {
            Libros libros = db.Libros.Find(id);
            if (libros == null)
            {
                return HttpNotFound();
            }
            ViewBag.EditorialID = new SelectList(db.Editorial, "EditorialID", "Nombre", libros.EditorialID);
            return View(libros);
        }

        //
        // POST: /Libros/Edit/5

        [HttpPost]
        public ActionResult Edit(Libros libros)
        {
            if (ModelState.IsValid)
            {
                db.Entry(libros).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.EditorialID = new SelectList(db.Editorial, "EditorialID", "Nombre", libros.EditorialID);
            return View(libros);
        }

        //
        // GET: /Libros/Delete/5

        public ActionResult Delete(string id = null)
        {
            Libros libros = db.Libros.Find(id);
            if (libros == null)
            {
                return HttpNotFound();
            }
            return View(libros);
        }

        //
        // POST: /Libros/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(string id)
        {
            Libros libros = db.Libros.Find(id);
            libros.Genero.Clear();
            libros.Autor.Clear();
            db.Libros.Remove(libros);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}