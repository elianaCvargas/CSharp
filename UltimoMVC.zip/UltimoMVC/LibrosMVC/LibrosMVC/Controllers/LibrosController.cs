﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LibrosMVC.Models;

namespace LibrosMVC.Controllers
{
    public class LibrosController : Controller
    {
        private LibrosEntities db = new LibrosEntities();

        //
        // GET: /Libros/

        public ActionResult Index()
        {
            var libros = db.Libros.Include(l => l.Editorial);
            ViewBag.edi = new SelectList(db.Editorial, "EditorialID", "Nombre");//este es el  nuevo  contenedor de seleccion
            return View(libros.ToList());
        }
        [HttpPost]//Este tag es para cuando  creamos  un  formulario,  si  esto  no  valida el  post
        public ActionResult Index(FormCollection fm)// es lo  mismo  que un  submit
        {
            ViewBag.edi = new SelectList(db.Editorial, "EditorialID", "Nombre");
            
            string post = fm["edi"];
            if (post == "")
            {
                return View(db.Libros);
            }
            int id = int.Parse(post);

            
            return View(db.Libros.Where(a=>a.EditorialID == id));
        }



        

        //
        // GET: /Libros/Details/5

        public ActionResult Details(int id = 0)
        {
            Libros libros = db.Libros.Find(id);

           
            if (libros == null)
            {
                return HttpNotFound();
            }
            
            return View(libros);
        }

        //
        // GET: /Libros/Create

        public ActionResult Create()
        {
            ViewBag.EditorialID = new SelectList(db.Editorial, "EditorialID", "Nombre");
            return View();
        }






        //
        // POST: /Libros/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Libros libros)
        {
            if (ModelState.IsValid)
            {
                Autor au = new Autor();
                au.Nombre = Request["Aut"];

                Genero gen = new Genero();
                gen.Nombre = Request["gen"];
                libros.Autor.Add(au);
                libros.Genero.Add(gen);

                db.Libros.Add(libros);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.EditorialID = new SelectList(db.Editorial, "EditorialID", "Nombre", libros.EditorialID);
            return View(libros);
        }


       






        //
        // GET: /Libros/Edit/5

        public ActionResult Edit(int id = 0)
        {
            
            Libros libros = db.Libros.Find(id);           

            //Autor autor = db.Autor.Find(id);

            ViewBag.aut = new SelectList(db.Autor, "AutorID", "Nombre");
            ViewBag.EditorialID = new SelectList(db.Editorial, "EditorialID", "Nombre", libros.EditorialID);

            if (libros == null)
            {
                return HttpNotFound();
            }
            

            return View(libros);
        }









        //
        // POST: /Libros/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Libros libros)
        {
           // ViewBag.aut = new SelectList(db.Autor, "AutorID", "Nombre");
            ViewBag.EditorialID = new SelectList(db.Editorial, "EditorialID", "Nombre", libros.EditorialID);
            
            if (ModelState.IsValid)
            {

                
                db.Entry(libros).State = EntityState.Modified;

                Autor au = new Autor();
                au.Nombre = Request["autor"];
                libros.Autor.Add(au);
                
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(libros);
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Edit(Libros libros, Autor autor)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(libros).State = EntityState.Modified;

        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    //ViewBag.Autor = new SelectList(db.Autor, "AutorID", "Nombre", autor.AutorID);

        //    ViewBag.EditorialID = new SelectList(db.Editorial, "EditorialID", "Nombre", libros.EditorialID);
        //    return View(libros);
        //}

        //
        // borrar autor de un  libro
        //
        public ActionResult DeleteAutor(int id, int  id2)
        {

            var lib = db.Libros.Find(id2);
            lib.Autor.Remove(db.Autor.Find(id));
            db.SaveChanges();
            return RedirectToAction("Edit", new {  id =  id2});

        }
        //
        // Agregar autor de un  libro
        //





        public ActionResult Delete(int id = 0)
        {
            
            Libros libros = db.Libros.Find(id);

            if (libros == null)
            {
                return HttpNotFound();
            }
            db.SaveChanges();
            return View(libros);
        }
        //
        // POST: /Libros/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Libros libros = db.Libros.Find(id);
            libros.Autor.Clear();
            libros.Genero.Clear();
            db.Libros.Remove(libros);
            db.SaveChanges();
            return RedirectToAction("Index");
        }






        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}