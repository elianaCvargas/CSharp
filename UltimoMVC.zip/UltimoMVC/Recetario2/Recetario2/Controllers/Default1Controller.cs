﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Recetario2.Models;

namespace Recetario2.Controllers
{
    public class Default1Controller : Controller
    {
        private RecetasEntities db = new RecetasEntities();

        //
        // GET: /Default1/

        public ActionResult Index()
        {
            return View(db.Recetas.ToList());
        }

        //
        // GET: /Default1/Details/5

        public ActionResult Details(int id = 0)
        {
            Recetas recetas = db.Recetas.Find(id);
            if (recetas == null)
            {
                return HttpNotFound();
            }
            return View(recetas);
        }

        //
        // GET: /Default1/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Default1/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Recetas recetas)
        {
            if (ModelState.IsValid)
            {
                db.Recetas.Add(recetas);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(recetas);
        }

        //
        // GET: /Default1/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Recetas recetas = db.Recetas.Find(id);
            if (recetas == null)
            {
                return HttpNotFound();
            }
            return View(recetas);
        }

        //
        // POST: /Default1/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Recetas recetas)
        {
            if (ModelState.IsValid)
            {
                db.Entry(recetas).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(recetas);
        }

        //
        // GET: /Default1/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Recetas recetas = db.Recetas.Find(id);
            if (recetas == null)
            {
                return HttpNotFound();
            }
            return View(recetas);
        }

        //
        // POST: /Default1/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Recetas recetas = db.Recetas.Find(id);

            recetas.RecetaIngrediente.Clear();

            db.Recetas.Remove(recetas);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult AgregarIngrediente()
        {
            return View();
        }
        //public ActionResult AgregarIngrediente()
        //{




        //    db.SaveChanges();

        //    return RedirectToAction("Index");


        //}

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}